"""Utilities for collecting a safe, compact Git repository context."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Dict, List, Optional


class RepoContextError(RuntimeError):
    """Raised when the requested directory is not a usable Git repository."""


def _run_git(repo: Path, *args: str, max_output: Optional[int] = None) -> str:
    try:
        result = subprocess.run(
            ["git", "-c", "core.quotepath=false", *args],
            cwd=str(repo),
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
    except OSError as exc:
        raise RepoContextError(f"无法执行 git: {exc}") from exc

    if result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip()
        raise RepoContextError(message or "git 命令执行失败")

    output = result.stdout
    return output if max_output is None else output[:max_output]


def is_git_repo(path: Path) -> bool:
    try:
        _run_git(path, "rev-parse", "--show-toplevel")
        return True
    except RepoContextError:
        return False


def decode_git_path(path: str) -> str:
    """Decode Git's C-quoted UTF-8 paths, including octal escapes."""
    if not (path.startswith('"') and path.endswith('"')):
        return path
    escapes = {'a': '\a', 'b': '\b', 't': '\t', 'n': '\n',
               'v': '\v', 'f': '\f', 'r': '\r', '\\': '\\', '"': '"'}

    def unescape(token):
        token = token.decode('ascii')
        return bytes([int(token, 8)]) if token[0].isdigit() else escapes.get(token, token).encode('utf-8')
    raw = re.sub(rb'\\([0-7]{1,3}|.)',
                 lambda m: unescape(m.group(1)),
                 path[1:-1].encode('utf-8'))
    return raw.decode('utf-8', errors='replace')


def collect_repo_context(
    path: str = ".",
    staged: bool = False,
    include_untracked: bool = True,
    max_diff_chars: int = 50000,
) -> Dict:
    """Collect repository metadata and a bounded diff for an Agent run."""
    repo = Path(path).resolve()
    if not is_git_repo(repo):
        raise RepoContextError(f"不是 Git 仓库: {repo}")

    root = Path(_run_git(repo, "rev-parse", "--show-toplevel").strip()).resolve()
    branch = _run_git(root, "branch", "--show-current").strip() or "(detached)"
    status = _run_git(root, "status", "--short", max_output=4000)
    diff_args = ["diff", "--no-ext-diff", "--no-textconv", "--unified=3"]
    if staged:
        diff_args.insert(1, "--cached")
    full_diff = _run_git(root, *diff_args)
    diff = full_diff[:max_diff_chars]

    file_args = ["diff", "--name-only", "-z"]
    if staged:
        file_args.append("--cached")
    changed_files: List[str] = [name for name in _run_git(root, *file_args).split('\0') if name]
    stat_args = ["diff", "--no-ext-diff", "--no-textconv", "--numstat", "--no-renames", "-z"]
    if staged:
        stat_args.append("--cached")
    unreviewed_files = []
    for row in _run_git(root, *stat_args).split('\0'):
        if row.startswith('-\t-\t'):
            unreviewed_files.append(row.split('\t', 2)[2])
    untracked = _run_git(root, 'ls-files', '--others', '--exclude-standard', '-z').split('\0')
    untracked = [name for name in untracked if name]

    return {
        "root": str(root),
        "branch": branch,
        "staged": staged,
        "status": status,
        "changed_files": changed_files,
        "diff": diff,
        "diff_truncated": len(full_diff) > max_diff_chars,
        "diff_total_chars": len(full_diff),
        "untracked_files": untracked,
        "unreviewed_files": unreviewed_files,
    }


def review_coverage(context: Dict) -> Dict:
    """Describe missing review content independently of the model's verdict."""
    notes = []
    if context.get('diff_truncated'):
        notes.append(f"diff 被截断，只提供 {len(context.get('diff', ''))} / "
                     f"{context.get('diff_total_chars', '?')} 字符")
    unreviewed = context.get('unreviewed_files') or []
    if unreviewed:
        notes.append('未提供二进制文件内容: ' + ', '.join(unreviewed))
    return {
        'coverage': 'partial' if notes else 'full',
        'coverage_note': '；'.join(notes),
        'unreviewed_files': unreviewed,
    }


def format_repo_prompt(context: Dict) -> str:
    """Turn repository context into a bounded prompt section."""
    files = "\n".join(f"- {name}" for name in context.get("changed_files", [])) or "(无工作区变更)"
    scope = ""
    if context.get("diff_truncated"):
        scope = (
            f"\n【审查范围警告】diff 已被截断：下面只包含完整 diff {context.get('diff_total_chars', '?')} 字符中的前 "
            f"{len(context.get('diff', ''))} 字符，末尾可能在文件或代码行中间被切断，后面的改动没有提供给你。"
            "只能对已提供部分下结论；不得把未提供的改动当作没有问题，"
            "也不得因为已看到的部分没有问题就给出 approve。\n"
        )
    if context.get('unreviewed_files'):
        scope += ('\n【审查范围警告】' + review_coverage(context)['coverage_note'] +
                  '。只能评价已提供内容，不得给整个改动 approve。\n')
    return f"""Git PR diff 审查任务。只根据下面的 diff 指出可证实的问题；不要把状态列表当成代码内容。
diff 中以 "-" 开头的行是已删除的代码，只有 "+" 开头的行才是改动后的代码；不要把删除行当作现有问题。{scope}
仓库上下文:
- 根目录: {context.get('root', '')}
- 分支: {context.get('branch', '')}
- 检查范围: {'暂存区' if context.get('staged') else '工作区'}
- 变更文件:
{files}

Git 状态:
{context.get('status', '(clean)') or '(clean)'}

Git diff:
{context.get('diff', '(无 diff)') or '(无 diff)'}

未跟踪文件仅列在状态中，尚未纳入 diff，也未经过审查。
"""
